<?php $__env->startSection('title', 'History Penggunaan - Admin Panel'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen py-8 md:py-12">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
                <h1 class="text-3xl sm:text-4xl font-bold mb-2 text-white">History Penggunaan</h1>
                <p class="text-gray-400">Lihat semua history penggunaan sistem perhitungan tarif</p>
            </div>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="mt-4 md:mt-0 px-6 py-3 bg-slate-700/50 border border-slate-600 text-gray-300 font-semibold rounded-xl hover:bg-slate-700 transition-all duration-200">
                <i class="fas fa-arrow-left mr-2"></i>
                Kembali ke Dashboard
            </a>
        </div>

        <div class="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 shadow-xl">
            <?php if($history->count() > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full border-collapse">
                        <thead>
                            <tr class="bg-gradient-to-r from-cyan-600 to-blue-600">
                                <th class="px-4 py-4 text-left text-sm font-bold text-white border-b-2 border-cyan-400/50">Tanggal & Waktu</th>
                                <th class="px-4 py-4 text-left text-sm font-bold text-white border-b-2 border-cyan-400/50">Kota User</th>
                                <th class="px-4 py-4 text-left text-sm font-bold text-white border-b-2 border-cyan-400/50">Kota Pembanding</th>
                                <th class="px-4 py-4 text-right text-sm font-bold text-white border-b-2 border-cyan-400/50">Tarif Aktual</th>
                                <th class="px-4 py-4 text-right text-sm font-bold text-white border-b-2 border-cyan-400/50">Tarif Rekomendasi</th>
                                <th class="px-4 py-4 text-right text-sm font-bold text-white border-b-2 border-cyan-400/50">Selisih</th>
                                <th class="px-4 py-4 text-right text-sm font-bold text-white border-b-2 border-cyan-400/50">Skor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b border-slate-700/30 hover:bg-slate-700/30 transition-colors">
                                    <td class="px-4 py-4 text-gray-300 text-sm">
                                        <?php if($hist->created_at): ?>
                                            <div class="font-medium text-white"><?php echo e($hist->created_at->format('d/m/Y')); ?></div>
                                            <div class="text-xs text-gray-400 mt-1"><?php echo e($hist->created_at->format('H:i:s')); ?></div>
                                        <?php else: ?>
                                            <span class="text-gray-500">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-4">
                                        <div class="font-semibold text-white text-sm mb-1"><?php echo e(ucfirst($hist->nama_kota_user)); ?></div>
                                        <div class="text-xs text-gray-400">UMR: Rp <?php echo e(number_format($hist->umr_user, 0, ',', '.')); ?></div>
                                    </td>
                                    <td class="px-4 py-4">
                                        <?php if($hist->kotaPembanding): ?>
                                            <span class="inline-flex items-center px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 font-medium text-sm border border-cyan-500/40">
                                                <?php echo e($hist->kotaPembanding->nama_kota); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-500">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-4 text-right text-gray-300 text-sm">
                                        <span class="font-medium">Rp <?php echo e(number_format($hist->tarif_minimum_aktual_user, 0, ',', '.')); ?></span>
                                    </td>
                                    <td class="px-4 py-4 text-right">
                                        <span class="font-bold text-cyan-400 text-sm">Rp <?php echo e(number_format($hist->tarif_rekomendasi, 0, ',', '.')); ?></span>
                                    </td>
                                    <td class="px-4 py-4 text-right">
                                        <span class="inline-flex items-center px-3 py-1.5 rounded-lg font-semibold text-sm <?php echo e($hist->selisih >= 0 ? 'bg-green-500/20 text-green-300 border border-green-500/40' : 'bg-red-500/20 text-red-300 border border-red-500/40'); ?>">
                                            <?php echo e($hist->selisih >= 0 ? '+' : ''); ?>Rp <?php echo e(number_format(abs($hist->selisih), 0, ',', '.')); ?>

                                        </span>
                                    </td>
                                    <td class="px-4 py-4 text-right text-xs">
                                        <div class="space-y-1">
                                            <div class="text-cyan-400 font-medium">
                                                User: <span class="text-white font-semibold"><?php echo e(number_format($hist->skor_user, 4, ',', '.')); ?></span>
                                            </div>
                                            <div class="text-gray-400">
                                                Pembanding: <span class="text-gray-300 font-semibold"><?php echo e(number_format($hist->skor_pembanding, 4, ',', '.')); ?></span>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-6 flex justify-center">
                    <?php echo e($history->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-12">
                    <i class="fas fa-history text-6xl text-gray-600 mb-4"></i>
                    <p class="text-gray-400">Belum ada history penggunaan</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Magang\HitungTarif - Copy\resources\views/admin/history.blade.php ENDPATH**/ ?>