<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perbandingan Kota - Sistem AHP & SAW</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        :root {
            --dark-blue: #0a192f;
            --light-blue: #172a46;
            --accent-cyan: #64ffda;
            --light-slate: #ccd6f6;
            --slate: #8892b0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--dark-blue);
            color: var(--light-slate);
        }

        .navbar {
            background-color: rgba(10, 25, 47, 0.85);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            color: var(--accent-cyan);
            font-weight: 600;
        }

        .nav-link {
            color: var(--slate);
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            color: var(--accent-cyan);
        }

        .hero {
            background: linear-gradient(rgba(10, 25, 47, 0.95), rgba(10, 25, 47, 0.95));
            padding: 80px 0;
            text-align: center;
        }

        .hero h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--light-slate);
        }

        .card {
            background-color: var(--light-blue);
            border: 1px solid #1d3b66;
            border-radius: 10px;
        }

        .card-header {
            background-color: #1d3b66;
            border-bottom: 1px solid #1d3b66;
            color: var(--light-slate);
            font-weight: 600;
        }

        .form-control {
            background-color: #1d3b66;
            border: 1px solid #1d3b66;
            color: var(--light-slate);
        }

        .form-control:focus {
            background-color: #1d3b66;
            border-color: var(--accent-cyan);
            color: var(--light-slate);
            box-shadow: 0 0 0 0.2rem rgba(100, 255, 218, 0.25);
        }

        .form-label {
            color: var(--light-slate);
            font-weight: 500;
        }

        .btn-primary-custom {
            background-color: var(--accent-cyan);
            border-color: var(--accent-cyan);
            color: var(--dark-blue);
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            background-color: #55e3c4;
            border-color: #55e3c4;
            transform: translateY(-3px);
        }

        .btn-secondary-custom {
            background-color: transparent;
            border: 1px solid var(--slate);
            color: var(--slate);
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-secondary-custom:hover {
            background-color: var(--slate);
            color: var(--dark-blue);
        }

        .vs-text {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent-cyan);
            text-align: center;
            margin: 1rem 0;
        }

        .city-card {
            background: linear-gradient(135deg, var(--light-blue), #1d3b66);
            border: 2px solid #1d3b66;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .city-card:hover {
            border-color: var(--accent-cyan);
            transform: translateY(-5px);
        }

        .city-name {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--accent-cyan);
            margin-bottom: 1rem;
        }

        .city-detail {
            font-size: 0.9rem;
            color: var(--slate);
            margin-bottom: 0.5rem;
        }

        .text-muted {
            color: #8892b0 !important;
        }

        .form-text {
            color: #8892b0 !important;
        }

        .text-danger {
            color: #ff6b6b !important;
        }

        .alert-info {
            background-color: rgba(100, 255, 218, 0.1);
            border: 1px solid var(--accent-cyan);
            color: var(--light-slate);
        }

        .alert-info .fas {
            color: var(--accent-cyan);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Sistem AHP & SAW</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('ahp-saw.index')); ?>">Data Kota</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('ahp-saw.perhitungan')); ?>">Perhitungan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('ahp-saw.perbandingan')); ?>">Perbandingan</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero">
        <div class="container">
            <h1>Perbandingan Kota</h1>
            <p class="lead">Bandingkan dua kota untuk mendapatkan rekomendasi tarif transportasi</p>
        </div>
    </div>

    <div class="container py-5">
        <?php if($kota->count() < 2): ?>
            <div class="alert alert-warning" role="alert">
                <i class="fas fa-exclamation-triangle"></i>
                <strong>Peringatan!</strong> Minimal diperlukan 2 kota untuk melakukan perbandingan.
                <a href="<?php echo e(route('ahp-saw.create')); ?>" class="alert-link">Tambah kota</a> terlebih dahulu.
            </div>
        <?php else: ?>
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-balance-scale"></i> Pilih Kota untuk Dibandingkan
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="alert alert-info mb-4" role="alert">
                                <i class="fas fa-info-circle"></i>
                                <strong>Informasi:</strong> Hanya Jakarta dan Bandung yang dapat menjadi kota acuan karena memiliki data tarif minimum aktual yang valid untuk perhitungan rekomendasi tarif.
                            </div>
                            
                            <form action="<?php echo e(route('ahp-saw.bandingkan')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                
                                <div class="row">
                                    <div class="col-md-5">
                                        <label for="kota_acuan_id" class="form-label">Kota Acuan (Referensi) <span class="text-danger">*</span></label>
                                        <select class="form-control <?php $__errorArgs = ['kota_acuan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="kota_acuan_id" name="kota_acuan_id" required>
                                            <option value="">Pilih Kota Acuan</option>
                                            <?php $__currentLoopData = $kotaAcuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k->id); ?>" <?php echo e(old('kota_acuan_id') == $k->id ? 'selected' : ''); ?>>
                                                    <?php echo e($k->nama_kota); ?> (Rp <?php echo e(number_format($k->tarif_minimum_aktual, 0, ',', '.')); ?>)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kota_acuan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-2 d-flex align-items-end justify-content-center">
                                        <div class="vs-text">VS</div>
                                    </div>

                                    <div class="col-md-5">
                                        <label for="kota_banding_id" class="form-label">Kota yang Dibandingkan <span class="text-danger">*</span></label>
                                        <select class="form-control <?php $__errorArgs = ['kota_banding_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="kota_banding_id" name="kota_banding_id" required>
                                            <option value="">Pilih Kota Banding</option>
                                            <?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k->id); ?>" <?php echo e(old('kota_banding_id') == $k->id ? 'selected' : ''); ?>>
                                                    <?php echo e($k->nama_kota); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kota_banding_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mt-4">
                                    <div class="col-12 text-center">
                                        <button type="submit" class="btn btn-primary-custom btn-lg">
                                            <i class="fas fa-play"></i> Bandingkan Kota
                                        </button>
                                        <a href="<?php echo e(route('ahp-saw.perhitungan')); ?>" class="btn btn-secondary-custom btn-lg ms-3">
                                            <i class="fas fa-arrow-left"></i> Kembali ke Perhitungan
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-12">
                    <h4 class="text-center mb-4">Daftar Kota Tersedia</h4>
                    <div class="row">
                        <?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-3">
                            <div class="city-card">
                                <div class="city-name"><?php echo e($k->nama_kota); ?></div>
                                <div class="city-detail">
                                    <strong>UMR:</strong> Rp <?php echo e(number_format($k->umr, 0, ',', '.')); ?>

                                </div>
                                <div class="city-detail">
                                    <strong>Waktu Tempuh:</strong> <?php echo e($k->waktu_tempuh); ?> detik/km
                                </div>
                                <div class="city-detail">
                                    <strong>Armada:</strong> <?php echo e(number_format($k->jumlah_armada, 0, ',', '.')); ?>

                                </div>
                                <div class="city-detail">
                                    <strong>Kendaraan Pribadi:</strong> <?php echo e(number_format($k->jumlah_kendaraan_pribadi, 0, ',', '.')); ?>

                                </div>
                                <?php if($k->tarif_minimum_aktual): ?>
                                <div class="city-detail">
                                    <strong>Tarif Minimum:</strong> Rp <?php echo e(number_format($k->tarif_minimum_aktual, 0, ',', '.')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\Magang\HitungTarif\resources\views/ahp-saw/perbandingan.blade.php ENDPATH**/ ?>