<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Analisis Tarif Transportasi Online</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #64748b;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #1e293b;
            --light: #f8fafc;
        }

        body {
            background-color: var(--light);
            font-family: 'Inter', sans-serif;
        }

        .dashboard-header {
            background: linear-gradient(135deg, var(--primary), #1d4ed8);
            color: white;
            padding: 2rem 0;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border-left: 4px solid var(--primary);
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-card.success { border-left-color: var(--success); }
        .stat-card.warning { border-left-color: var(--warning); }
        .stat-card.danger { border-left-color: var(--danger); }

        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .comparison-table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background-color: var(--primary);
            color: white;
            border: none;
            font-weight: 600;
        }

        .price-tag {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--success);
        }

        .trend-up { color: var(--success); }
        .trend-down { color: var(--danger); }
        .trend-stable { color: var(--secondary); }
    </style>
</head>
<body>
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-2"><i class="fas fa-chart-line me-2"></i>Dashboard Analisis Tarif</h1>
                    <p class="mb-0">Analisis komprehensif tarif transportasi online di 5 kota besar Indonesia</p>
                </div>
                <div class="col-md-4 text-end">
                    <button class="btn btn-light">
                        <i class="fas fa-download me-1"></i>Export Data
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="container py-4">
        <!-- Statistik Overview -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Rata-rata Tarif</h6>
                            <h3 class="price-tag mb-0">Rp 6.100</h3>
                        </div>
                        <i class="fas fa-money-bill-wave fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card success">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Kota Termurah</h6>
                            <h4 class="mb-0">Palembang</h4>
                            <small class="text-success">Rp 4.500</small>
                        </div>
                        <i class="fas fa-trophy fa-2x text-success"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card warning">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Kota Termahal</h6>
                            <h4 class="mb-0">Jakarta</h4>
                            <small class="text-warning">Rp 8.000</small>
                        </div>
                        <i class="fas fa-crown fa-2x text-warning"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card danger">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Selisih Terbesar</h6>
                            <h4 class="mb-0">Rp 3.500</h4>
                            <small class="text-danger">Jakarta vs Palembang</small>
                        </div>
                        <i class="fas fa-chart-bar fa-2x text-danger"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row">
            <div class="col-md-6">
                <div class="chart-container">
                    <h5 class="mb-3"><i class="fas fa-chart-bar me-2"></i>Perbandingan Tarif per Kota</h5>
                    <canvas id="tarifChart" height="300"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="chart-container">
                    <h5 class="mb-3"><i class="fas fa-chart-pie me-2"></i>Distribusi Market Share</h5>
                    <canvas id="marketChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- UMR vs Tarif Correlation -->
        <div class="row">
            <div class="col-md-8">
                <div class="chart-container">
                    <h5 class="mb-3"><i class="fas fa-chart-scatter me-2"></i>Korelasi UMR vs Tarif</h5>
                    <canvas id="correlationChart" height="300"></canvas>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chart-container">
                    <h5 class="mb-3"><i class="fas fa-tachometer-alt me-2"></i>Efisiensi Armada</h5>
                    <canvas id="efficiencyChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- Detailed Comparison Table -->
        <div class="row">
            <div class="col-12">
                <div class="comparison-table">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Kota</th>
                                <th>Tarif Aktual</th>
                                <th>Tarif Rekomendasi</th>
                                <th>UMR</th>
                                <th>Kemacetan</th>
                                <th>Armada</th>
                                <th>Skor AHP</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Jakarta</strong></td>
                                <td><span class="price-tag">Rp 8.000</span></td>
                                <td><span class="price-tag">Rp 8.000</span></td>
                                <td>Rp 5.396.761</td>
                                <td><span class="badge bg-danger">Tinggi</span></td>
                                <td>1.000.000</td>
                                <td>0.85</td>
                                <td><span class="trend-stable"><i class="fas fa-minus-circle"></i> Optimal</span></td>
                            </tr>
                            <tr>
                                <td><strong>Surabaya</strong></td>
                                <td><span class="price-tag">Rp 7.000</span></td>
                                <td><span class="price-tag">Rp 6.200</span></td>
                                <td>Rp 4.725.479</td>
                                <td><span class="badge bg-warning">Tinggi</span></td>
                                <td>15.350</td>
                                <td>0.72</td>
                                <td><span class="trend-up"><i class="fas fa-arrow-up"></i> Overpriced</span></td>
                            </tr>
                            <tr>
                                <td><strong>Bandung</strong></td>
                                <td><span class="price-tag">Rp 6.000</span></td>
                                <td><span class="price-tag">Rp 5.800</span></td>
                                <td>Rp 4.209.309</td>
                                <td><span class="badge bg-warning">Tinggi</span></td>
                                <td>30.000</td>
                                <td>0.68</td>
                                <td><span class="trend-up"><i class="fas fa-arrow-up"></i> Overpriced</span></td>
                            </tr>
                            <tr>
                                <td><strong>Medan</strong></td>
                                <td><span class="price-tag">Rp 5.000</span></td>
                                <td><span class="price-tag">Rp 5.500</span></td>
                                <td>Rp 3.769.082</td>
                                <td><span class="badge bg-warning">Tinggi</span></td>
                                <td>2.000</td>
                                <td>0.45</td>
                                <td><span class="trend-down"><i class="fas fa-arrow-down"></i> Underpriced</span></td>
                            </tr>
                            <tr>
                                <td><strong>Palembang</strong></td>
                                <td><span class="price-tag">Rp 4.500</span></td>
                                <td><span class="price-tag">Rp 4.200</span></td>
                                <td>Rp 3.677.591</td>
                                <td><span class="badge bg-success">Rendah</span></td>
                                <td>25.000</td>
                                <td>0.38</td>
                                <td><span class="trend-up"><i class="fas fa-arrow-up"></i> Overpriced</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Tarif Comparison Chart
        const tarifCtx = document.getElementById('tarifChart').getContext('2d');
        new Chart(tarifCtx, {
            type: 'bar',
            data: {
                labels: ['Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Palembang'],
                datasets: [{
                    label: 'Tarif Aktual',
                    data: [8000, 7000, 6000, 5000, 4500],
                    backgroundColor: '#2563eb',
                    borderColor: '#1d4ed8',
                    borderWidth: 2
                }, {
                    label: 'Tarif Rekomendasi',
                    data: [8000, 6200, 5800, 5500, 4200],
                    backgroundColor: '#10b981',
                    borderColor: '#059669',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });

        // Market Share Chart
        const marketCtx = document.getElementById('marketChart').getContext('2d');
        new Chart(marketCtx, {
            type: 'doughnut',
            data: {
                labels: ['Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Palembang'],
                datasets: [{
                    data: [1000000, 15350, 30000, 2000, 25000],
                    backgroundColor: [
                        '#2563eb',
                        '#10b981',
                        '#f59e0b',
                        '#ef4444',
                        '#8b5cf6'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });

        // UMR vs Tarif Correlation
        const correlationCtx = document.getElementById('correlationChart').getContext('2d');
        new Chart(correlationCtx, {
            type: 'scatter',
            data: {
                datasets: [{
                    label: 'UMR vs Tarif',
                    data: [
                        {x: 5396761, y: 8000},
                        {x: 4725479, y: 7000},
                        {x: 4209309, y: 6000},
                        {x: 3769082, y: 5000},
                        {x: 3677591, y: 4500}
                    ],
                    backgroundColor: '#2563eb',
                    borderColor: '#1d4ed8',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'UMR (Rupiah)'
                        },
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + (value/1000000).toFixed(1) + 'M';
                            }
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Tarif (Rupiah)'
                        },
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });

        // Efficiency Chart
        const efficiencyCtx = document.getElementById('efficiencyChart').getContext('2d');
        new Chart(efficiencyCtx, {
            type: 'radar',
            data: {
                labels: ['Armada', 'Efisiensi', 'Kemacetan', 'UMR', 'Kendaraan'],
                datasets: [{
                    label: 'Jakarta',
                    data: [100, 85, 20, 100, 100],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.2)'
                }, {
                    label: 'Surabaya',
                    data: [15, 70, 30, 88, 95],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.2)'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    </script>
</body>
</html>
<?php /**PATH D:\Magang\HitungTarif\resources\views/tarif-dashboard.blade.php ENDPATH**/ ?>